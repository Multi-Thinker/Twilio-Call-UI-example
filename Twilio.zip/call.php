<?php 
require_once "./twilio-php-master/Twilio/autoload.php";
require_once "./twilio-php-master/Twilio/Twiml.php";
use Twilio\TwiML;

if(!isset($_GET['print'])){
    $response = new TwiML();
    $response->dial('415-123-4567', ['action' => './call.php?print',
        'method' => 'GET']);
    $response->say('I am unreachable');
    echo $response;
}else{
    print_r($_GET);
}
?>